﻿using System.ComponentModel.DataAnnotations;

namespace Schuelerverwaltung.Models
{

	public class Professor
	{
		public int Id { get; set; }
		[Required]
		public string Vorname { get; set; }
        [Required]
        public string Nachname { get; set; }
        [Required]
        public string Email { get; set; }
		public string? Titel { get; set; }
		public string? Abteilung { get; set; }
		public List<Schueler> Schueler {  get; set; } = new List<Schueler>();
		public string? OwnerUser { get; set; }
	}
}
