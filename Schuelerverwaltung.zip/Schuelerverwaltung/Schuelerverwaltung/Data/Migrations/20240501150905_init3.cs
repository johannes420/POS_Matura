﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Schuelerverwaltung.Data.Migrations
{
    /// <inheritdoc />
    public partial class init3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "note",
                table: "schueler",
                newName: "Note");

            migrationBuilder.RenameColumn(
                name: "klasse",
                table: "schueler",
                newName: "Klasse");

            migrationBuilder.RenameColumn(
                name: "isActive",
                table: "schueler",
                newName: "IsActive");

            migrationBuilder.AlterColumn<float>(
                name: "Note",
                table: "schueler",
                type: "real",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Note",
                table: "schueler",
                newName: "note");

            migrationBuilder.RenameColumn(
                name: "Klasse",
                table: "schueler",
                newName: "klasse");

            migrationBuilder.RenameColumn(
                name: "IsActive",
                table: "schueler",
                newName: "isActive");

            migrationBuilder.AlterColumn<int>(
                name: "note",
                table: "schueler",
                type: "int",
                nullable: true,
                oldClrType: typeof(float),
                oldType: "real",
                oldNullable: true);
        }
    }
}
