﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client.Kerberos;
using Smart_Meter.Data;
using Smart_Meter.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Smart_Meter.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SmartMeterController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public SmartMeterController(ApplicationDbContext context)
        {
            _context = context;
        }


        // GET api/<SmartMeterController>/5
        [HttpGet("GetData/{id}")]
        public List<Messwert> Get([FromRoute] int id)
        {
            List<Messwert> result = new List<Messwert>();

            Kunde? kunde = _context.Kunden.Include(k => k.ZaehlerList).FirstOrDefault(k => k.Id == id);

            if (kunde != null)
            {
                foreach (Zaehler z in kunde.ZaehlerList)
                {
                    result.AddRange(_context.Messwerte.Where(m => m.ZaehlerId == z.Id));
                }
            }

            return result;
        }


        // GET api/<SmartMeterController>/5
        [HttpGet("status")]
        public string status()
        {
            return "Service is up!";
        }

        // POST api/<SmartMeterController>/InsertData
        [HttpPost("InsertData")]
        public void InsertData()
        {
            Messwert m1 = new Messwert { Value = 361, Start = new DateTime(day: 1, month: 4, year: 2024, hour: 6, minute: 45, second: 0), End = new DateTime(day: 1, month: 4, year: 2024, hour: 7, minute: 0, second: 0) };
            Messwert m2 = new Messwert { Value = 420, Start = new DateTime(day: 1, month: 4, year: 2024, hour: 7, minute: 0, second: 0), End = new DateTime(day: 1, month: 4, year: 2024, hour: 7, minute: 15, second: 0) };
            Zaehler z1 = new Zaehler { MacAdresse = "13-6D-C1-8D-1E-1C" };
            z1.Messwerte.Add(m1);
            z1.Messwerte.Add(m2);

            Kunde k1 = new Kunde { Vorname = "Amir", Nachname = "Affe", Anschrift = "Radstadt", Email = "187@420.de", OptIn = true };
            k1.ZaehlerList.Add(z1);

            _context.Kunden.Add(k1);

            Messwert m3 = new Messwert { Value = 222, Start = new DateTime(day: 1, month: 4, year: 2024, hour: 7, minute: 0, second: 0), End = new DateTime(day: 2, month: 4, year: 2024, hour: 7, minute: 0, second: 0) };
            Messwert m4 = new Messwert { Value = 187, Start = new DateTime(day: 2, month: 4, year: 2024, hour: 7, minute: 0, second: 0), End = new DateTime(day: 3, month: 4, year: 2024, hour: 7, minute: 0, second: 0) };
            Zaehler z2 = new Zaehler { MacAdresse = "2C-6D-C1-8D-1E-1C" };
            z2.Messwerte.Add(m3);
            z2.Messwerte.Add(m4);

            Kunde k2 = new Kunde { Vorname = "Janei", Nachname = "Papaya", Anschrift = "Bhofn", Email = "420@187.at", OptIn = false };
            k2.ZaehlerList.Add(z2);

            _context.Kunden.Add(k2);
            _context.SaveChanges();
        }

        // POST api/<SmartMeterController>/AddPriceRange
        [HttpPost("AddPriceRange")]
        public void AddPriceRange([FromBody] Preis preis)
        {
            _context.Preise.Add(preis);
            _context.SaveChanges();
        }
    }
}
