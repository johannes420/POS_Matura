﻿using System.Text.Json.Serialization;

namespace Smart_Meter.Models
{
    public class Preis
    {
        public int Id { get; set; }
        [JsonPropertyName("price")]
        public float Value { get; set; }
        [JsonPropertyName("datefrom")]
        public DateTime Start { get; set; }
        [JsonPropertyName("dateto")]
        public DateTime End { get; set; }

        public bool isInPeriod(DateTime time)
        {
            if(time >= Start && time <= End)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
